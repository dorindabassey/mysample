#include <iostream>
#include "functions.h"

int main()
{
    print_name();
    std::cout << "the factorial of 6 is " << factorial(6) << std::endl;
    return 0;
}
