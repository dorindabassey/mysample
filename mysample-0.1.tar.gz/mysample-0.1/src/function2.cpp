#include <iostream>
#include "functions.h"

void print_name()
{
    std::cout << "my name is Dorinda\n";
}
