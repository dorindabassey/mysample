//declare your functions that will be used in your .cpp here
void print_name();

int factorial(int i);
